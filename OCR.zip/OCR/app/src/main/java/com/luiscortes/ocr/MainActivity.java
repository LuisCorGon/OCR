package com.luiscortes.ocr;

import android.graphics.Color;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.luiscortes.ocr.Fragments.CameraFragment;
import com.luiscortes.ocr.Fragments.DocumentsFragment;
import com.luiscortes.ocr.Fragments.ProfileFragment;
import com.luiscortes.ocr.Fragments.SettingsFragment;
import com.luiscortes.ocr.Fragments.UploadFragment;
import com.luiscortes.ocr.R;

import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.app.ActionBarDrawerToggle;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setBackgroundColor(Color.TRANSPARENT);
        bottomNav.getBackground().setAlpha(0);
        bottomNav.setElevation(0);
        bottomNav.setItemIconTintList(null);

        // Configurar el DrawerLayout y la barra superior (Toolbar)
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawerLayout = findViewById(R.id.drawerLayout);
        NavigationView navigationView = findViewById(R.id.navigationView);

        // Agregar botón de hamburguesa para abrir el DrawerLayout
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Manejar navegación del DrawerLayout (menú lateral)
        navigationView.setNavigationItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_profile) {
                replaceFragment(new ProfileFragment());
            } else if (item.getItemId() == R.id.nav_settings){
                replaceFragment(new SettingsFragment());
            } else if (item.getItemId() == R.id.nav_logout) {
                // Aquí puedes implementar la lógica de cierre de sesión
            }
            drawerLayout.closeDrawers(); // Cerrar el menú después de seleccionar
            return true;
        });

        // Manejar navegación del BottomNavigationView (barra inferior)
        bottomNav.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;

                if (item.getItemId() == R.id.nav_upload) {
                    selectedFragment = new UploadFragment();
                } else if (item.getItemId() == R.id.nav_camera) {
                    selectedFragment = new CameraFragment();
                } else if (item.getItemId() == R.id.nav_results) {
                    selectedFragment = new DocumentsFragment();
                }
            if (selectedFragment != null) {
                replaceFragment(selectedFragment);
            }

            return true;
        });

        // Cargar el fragmento de la cámara por defecto
        if (savedInstanceState == null) {
            replaceFragment(new CameraFragment());
        }
    }

    // Método para reemplazar fragments dinámicamente
    private void replaceFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.frameContainer, fragment)
                .commit();

    }

}